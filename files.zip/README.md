# 📄 LocalPDF — Private PDF Toolkit

A fully **client-side** PDF toolkit that runs entirely in your browser. No uploads, no servers, no data leaves your device.

## ✨ Features

| Tool | Description |
|---|---|
| **Merge** | Combine multiple PDFs into one |
| **Split** | Divide a PDF into separate files |
| **Extract** | Pull out specific pages by range or selection |
| **Reorder** | Drag-and-drop page reordering |
| **Rotate** | Rotate pages (all, odd, even, or custom range) |
| **Watermark** | Add custom text watermarks with opacity & position control |
| **Page Numbers** | Stamp page numbers with custom format & position |
| **Compress** | Reduce file size and strip metadata |
| **Protect** | Password-protect with granular permissions (edit, copy, print) |
| **Unlock** | Remove password from an encrypted PDF |
| **PDF → Images** | Export pages as PNG or JPEG at custom scale |

## 🚀 Usage

No installation needed. Just open `LocalPDF.html` in any modern browser.

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/LocalPDF.git

# Open in browser
open LocalPDF.html
```

Or use it directly via GitHub Pages (if enabled).

## 🔒 Privacy

All PDF processing happens **100% locally** in your browser using:
- [pdf-lib](https://pdf-lib.js.org/) — PDF creation & manipulation
- [PDF.js](https://mozilla.github.io/pdf.js/) — PDF rendering & page preview

Your files are **never uploaded** anywhere.

## 🛠 Tech Stack

- Vanilla HTML, CSS, JavaScript — zero build step, zero dependencies to install
- `pdf-lib` v1.17.1 (via CDN)
- `pdf.js` v3.4.120 (via CDN)
- Google Fonts: Outfit + JetBrains Mono

## 📁 Project Structure

```
LocalPDF/
└── LocalPDF.html    # Entire app in a single file
```

## 📝 License

MIT — feel free to use, modify, and distribute.
